

$(document).ready(function() {
  console.info('%c[Workbench Extension]:'+'%c login.js', 'background:#999999;color:#FFFFFF', 'background:none;color:inherit');

});