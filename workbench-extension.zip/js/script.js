
$(document).ready(function() {
  // var list_objects = [];
  // $('#QB_object_sel option').each(function() {
  //   list_objects.append($(this).attr('value'));
  // });
  // console.log(list_objects);
  // alert('rouge');

});